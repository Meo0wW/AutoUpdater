﻿namespace AutoUpdater
{
	public class ApplicationInfo
	{
		public string Name { get; set; }
		public string Version { get; set; }
		public string Descriptions { get; set; }
		public string DownloadUrl { get; set; }
	}
}